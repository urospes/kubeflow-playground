If you are a contributor please consult [Best Practices](https://kubectl.docs.kubernetes.io/references/kustomize/) and the [main README.md](./README.md)
